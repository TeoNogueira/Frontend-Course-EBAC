## 👨‍💻 About me

Hello my name is Teófilo Nogueira currently studying at EBAC through the front-end engineering course, I develop front-end web applications, I love technology and I have been looking for daily knowledge, I am willing to face any challenges as a developer.

#
- 🌲 I'm fixing my knowledge in: html, css, javascript and ReactJs.
- 🤗 Highlight: teamwork helps people to grow and makes us reach deeper into our goals.
- 📚 My focus is on front-end development with languages and librarie ReactJs, bootstrap, material-design-iconic.
<br />



[<div align="center">![Instagram](https://img.shields.io/badge/-Instagram-057a7b?style=for-the-badge&logo=instagram&logoColor=fff)](https://www.instagram.com/teo_nogueira/) [![Instagram](https://img.shields.io/badge/-beginjscript-057a7b?style=for-the-badge&logo=Instagram&logoColor=77bcef)](https://www.instagram.com/beginjscript/)  [![Linkedin](https://img.shields.io/badge/-linkedin-057a7b?style=for-the-badge&logo=linkedin&logoColor=bffff9)</div>](https://www.linkedin.com/in/teonogueira/) [<div align="center" target="_blank">![Google Chrome](https://img.shields.io/badge/Current_Course_EBAC-800080?style=for-the-badge&logo=GoogleChrome&logoColor=fff)](https://ebaconline.com.br/front-end-profession/)

#
<br /> <br />
[<div align="center"> ![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=TeoNogueira&layout=compact) </div>](https://github.com/TeoNogueira/github-readme-stats)

#
<br /> <br />

[<div align="center"> ![image](https://user-images.githubusercontent.com/53917980/120089574-37fe2600-c0d2-11eb-93cc-0a67da3aacb6.png) </div>](https://github.com/TeoNogueira/github-readme-stats)





