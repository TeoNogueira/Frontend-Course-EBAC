function recursiva(numero) {

console.log(numero)

numero--

}


contagemRegressiva(10)


