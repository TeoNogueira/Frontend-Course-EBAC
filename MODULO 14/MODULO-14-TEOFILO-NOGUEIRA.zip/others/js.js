// const test = 15


// let a = 'test'

// let b = test


// if(a != b === true) {

// console.log(test + 5)

// }


// console.log(test)
// console.log(typeof a)

var modulo1 = 10

var modulo2 = 7

var modulo3 = 8

var modulo4 = 7

var mediaTeo = (modulo1 + modulo2 + modulo3 + modulo4) / 4;

console.log(mediaTeo)

if(mediaTeo > 7) {

  console.log('Aluno Aprovado!')
}

