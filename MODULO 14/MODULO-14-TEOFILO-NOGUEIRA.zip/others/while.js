
var hora = 24;


while(hora > 0) {

    hora--

    console.log(hora)

}

do {

execucao

}

while(condicao)